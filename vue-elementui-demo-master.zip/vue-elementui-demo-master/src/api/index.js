// import axios from 'axios'

// export const userApi = {
// 	userList() {
// 		return axios.get("localhost:8080/ssm/user/getAllUser.do").then((response) => {
// 			console.log("nnn");
// 			return response.data;
// 		})
// 	}
// }